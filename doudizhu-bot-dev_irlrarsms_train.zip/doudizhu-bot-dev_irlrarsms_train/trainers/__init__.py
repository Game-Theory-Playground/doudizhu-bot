from .base_trainer import BaseTrainer
from .dmc_trainer import DMCBotTrainer
# We'll import specific bots here later